// Service worker: deixa o app abrir offline. Aumente CACHE ao publicar uma nova versão.
const CACHE = "carteira-b3-v1";
const ARQUIVOS = ["./", "./index.html", "./data.js", "./manifest.webmanifest",
  "./icon-192.png", "./icon-512.png", "./icon-maskable-512.png"];

self.addEventListener("install", e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ARQUIVOS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

self.addEventListener("fetch", e => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== location.origin) return; // cotações (brapi) sempre vão à rede
  // arquivos do app: cache primeiro, atualiza em segundo plano
  e.respondWith(caches.match(req, {ignoreSearch: true}).then(hit => {
    const rede = fetch(req).then(r => {
      if (r.ok) caches.open(CACHE).then(c => c.put(req, r.clone()));
      return r;
    }).catch(() => hit);
    return hit || rede;
  }));
});
