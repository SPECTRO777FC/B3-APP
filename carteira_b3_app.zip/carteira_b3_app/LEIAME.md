# Carteira B3 — app para PC e celular

App web instalável (PWA). Funciona sem servidor próprio e sem internet depois da primeira abertura.
A carteira fica salva **no próprio aparelho** (nada é enviado a servidores).

## 1. Colocar no ar (grátis, uns 2 minutos)

O celular precisa abrir o app por um endereço https. Escolha UMA opção:

- **Netlify Drop** (mais fácil): abra https://app.netlify.com/drop, arraste esta pasta inteira e copie o endereço gerado.
- **GitHub Pages**: crie um repositório, envie estes arquivos, ative Settings → Pages.
- **Cloudflare Pages**: crie um projeto "Direct Upload" e envie a pasta.

Dica: o endereço gerado é público para quem o conhecer, mas a sua carteira não vai junto: ela fica só no seu aparelho.

## 2. Instalar

- **Android (Chrome):** abra o endereço → menu ⋮ → "Instalar app".
- **iPhone (Safari):** abra o endereço → Compartilhar → "Adicionar à Tela de Início".
- **PC (Chrome/Edge):** ícone de instalação na barra de endereço.

## 3. Só no PC, sem hospedar

- Dê dois cliques em `index.html` (abre direto, sem instalação nem modo offline), ou
- na pasta, rode `python -m http.server 8000` e abra http://localhost:8000 (permite instalar).

## 4. Cotações ao vivo

1. Crie uma conta grátis em https://brapi.dev e copie seu token.
2. No app: Ajustes → cole o token → volte à Carteira → "Atualizar preços".

O plano gratuito aceita 1 ativo por requisição; o app já faz uma chamada por ativo. Sem token, edite o preço de cada ativo à mão.

## 5. Seus dados

- Toque em um ativo para editar quantidade, preço médio, LPA, VPA, proventos e VP da cota.
- "Adicionar ativo" cria novos. Ações precisam de LPA, VPA e proventos 12m para ter preço justo; FIIs, do VP por cota.
- Ajustes → Backup (JSON) / Restaurar: é assim que você leva a carteira do PC para o celular.
- Ajustes → Exportar CSV: abre no Excel ou no Google Sheets.

## 6. Atualizar o app depois

Substitua os arquivos no mesmo lugar e aumente o número em `CACHE` dentro de `sw.js` (ex.: `carteira-b3-v2`) para os aparelhos pegarem a versão nova.

## Avisos

Ferramenta de estudo, não é recomendação de investimento. Graham e Bazin servem mal para bancos e para empresas com lucro em queda. Os fundamentos de referência (LPA, VPA, proventos, histórico de 15 anos do BBAS3) são do fechamento de 28/10/2026 e não se atualizam sozinhos.
